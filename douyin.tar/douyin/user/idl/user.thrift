namespace go user

struct RegistReq {
    1: string Name (api.body="username"); // 添加 api 注解为方便进行参数绑定
    2: string Password (api.body="password"); // 添加 api 注解为方便进行参数绑定
}

struct RegistResp {
    1: i32 status_code;
    2: string status_msg;
    3: i64 user_id;
    4: string token;
}


struct LoginReq {
    1: string Name (api.body="username"); // 添加 api 注解为方便进行参数绑定
    2: string Password (api.body="password"); // 添加 api 注解为方便进行参数绑定
}

struct LoginResp {
    1: i32 status_code;
    2: string status_msg;
    3: i64 user_id;
    4: string token;
}

struct InfoReq {
    1: i64 user_id;
    2: string token;
}

struct InfoResp {
    1: i32 status_code;
    2: string status_msg;
    3: User user;
}


struct User {
    1: i64 id;
    2: string name;
    3: i64 follow_count;
    4: i64 follower_count;
    5: bool is_follow;
}


service RegistService {
    RegistResp RegistMethod(1: RegistReq request) (api.post="/douyin/user/register");
}


service LoginService {
    LoginResp LoginMethod(1: LoginReq request) (api.post="/douyin/user/login");
}

service UserInfoService {
    InfoResp InfoMethod(1: InfoReq request) (api.get="/douyin/user");
}