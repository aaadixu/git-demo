package utils

import (
	"crypto/md5"
	"fmt"
	"testing"
)

func Test1(t *testing.T) {
	str := "abc123"

	//方法一
	data := []byte(str)
	has := md5.Sum(data)
	md5str1 := fmt.Sprintf("%x", has) //将[]byte转成16进制
	fmt.Println()
	fmt.Println(md5str1)
}
