package dal

import (
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var Db *gorm.DB

type User struct {
	gorm.Model
	UserName      string `gorm:"type:varchar(256);not null" json:"user_name"`
	Password      string `gorm:"type:varchar(256);not null" json:"password"`
	FollowCount   int    `gorm:"default:0" json:"follow_count"`
	FollowerCount int    `gorm:"default:0" json:"follower_count"`
	IsFollow      bool   `gorm:"default:false" json:"is_follow"`
}

func InitDB() {
	var err error
	dsn := "root:123456@root@tcp(82.157.231.210:3306)/douyin?charset=utf8&parseTime=True&loc=Local"
	Db, err = gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		panic("failed to connect database")
	}

	Db.AutoMigrate(&User{})
}
