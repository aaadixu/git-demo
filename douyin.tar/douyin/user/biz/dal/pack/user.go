package pack

import (
	"douyin/user/biz/dal"
	"douyin/user/biz/model/user"
)

func User(userDB dal.User) (user.User, error) {
	var resUser user.User

	resUser.Name = userDB.UserName
	resUser.ID = int64(userDB.ID)
	resUser.FollowCount = int64(userDB.FollowCount)
	resUser.FollowerCount = int64(userDB.FollowerCount)
	resUser.IsFollow = userDB.IsFollow

	return resUser, nil
}

func Users(usersDB []dal.User) ([]user.User, error) {
	users := make([]user.User, 0)
	for _, u := range usersDB {
		user2, err := User(u)
		if err != nil {
			return nil, err
		}
		users = append(users, user2)
	}
	return users, nil
}
