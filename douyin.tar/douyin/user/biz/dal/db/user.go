package db

import (
	"douyin/user/biz/dal"
	"douyin/user/biz/dal/pack"
	"douyin/user/biz/model/user"
	"fmt"
)

// 判断用户是否存在（注册检查）
func IsUserExist(username string) bool {

	var users []dal.User

	dal.Db.Where("user_name = ?", username).Find(&users)

	return len(users) == 1
}

// 添加用户（注册）
func AddUser(user dal.User) (uint, error) {
	res := dal.Db.Create(&user)

	if res.Error != nil {
		return 0, res.Error
	}
	return user.ID, nil
}

// 登录检查
func CheckUser(username, password string) ([]user.User, error) {
	fmt.Println(username, password)
	res := make([]dal.User, 0)
	if err := dal.Db.Where("user_name =  ? and password = ?", username, password).
		Find(&res).Error; err != nil {
		return nil, err
	}
	return pack.Users(res)
}

func UserInfo(id int64) (user.User, error) {
	var userdb dal.User

	dal.Db.Where("id = ?", id).Find(&userdb)

	res, err := pack.User(userdb)
	if err != nil {
		return user.User{}, err
	}

	return res, nil
}
